function carregarUsuarios() {
    //Requisição AJAX para buscar os usuários cadastrados em formato JSON

    var xhttp = new XMLHttpRequest();

    var url = "http://localhost/Daniel/crud_pi_template/app/controller/UsuarioController.php?action=listJson";
    
    xhttp.open('GET', url);

    xhttp.onload = function() {
        
        var listaUsuarios = document.getElementById("listaUsuarios");        
        listaUsuarios.innerHTML = ""; // Limpa a lista antes de adicionar os novos usuários
        var json = xhttp.responseText;
        var usuarios = JSON.parse(json);
        
        for(let i = 0; i < usuarios.length; i++){
            var usuario = usuarios[i];
            var li = document.createElement("li");
            li.innerHTML = usuario.nome;
            listaUsuarios.appendChild(li);
        }
    }

    xhttp.send();
}